function v= f1(t,u) 
v=-150*u+49-150* t ; 
end
