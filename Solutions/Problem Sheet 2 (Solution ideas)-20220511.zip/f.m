function z=f ( s, t )
% z=−20*s.*(1 − s )+0.1* t.ˆ3;
z = sin( s+t );
end