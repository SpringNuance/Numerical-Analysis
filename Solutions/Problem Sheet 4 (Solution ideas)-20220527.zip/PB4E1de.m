%%
alpha1=quadl('l1w' ,0,1)
alpha2=quadl('l2w' ,0,1)