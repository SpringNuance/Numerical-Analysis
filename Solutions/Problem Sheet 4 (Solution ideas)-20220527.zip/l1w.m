function y=l1w(x)
y=-7/24*sqrt(30)*(x-(15+2*sqrt (30))/35)./ sqrt(x); 
end