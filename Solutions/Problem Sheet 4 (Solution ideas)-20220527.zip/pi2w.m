function y=pi2w(x) 
y=[(x-(15-2*sqrt (30))/35).*...
(x-(15+2*sqrt (30))/35)].^2./ sqrt(x);
end

